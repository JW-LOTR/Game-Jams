import pygame
import sys
import Player

class Reckless_App():

    def __init__(self):
        pygame.init()
        pygame.font.init()
        self.screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
        self.score = 0
        self.monster_amount = 0
        self.FPS = 144
        self.active = True
        self.clock = pygame.time.Clock()
        self.width = self.screen.get_width()
        self.height = self.screen.get_height()
        self.player = Player.Player(self.width,self.height)
        self.hellmonster = Player.Hellmonster(self.width,self.height)
        self.rock_color = "#4f4f4f"
        self.font = pygame.font.SysFont("calibri",35,True)
        self.font_settings = pygame.font.SysFont("arial",25, True)
        self.world = [
            [pygame.Surface((self.width,self.height/20)),pygame.Surface((self.width,self.height/20)).get_rect(topleft = (0,0))],
            [pygame.Surface((self.width, self.height / 20)),pygame.Surface((self.width, self.height/20)).get_rect(bottomright=(self.width, self.height))],
            [pygame.Surface((self.width/40, self.height)),pygame.Surface((self.width/40, self.height)).get_rect(topleft=(0, 0))],
            [pygame.Surface((self.width/40, self.height)),pygame.Surface((self.width/40, self.height)).get_rect(bottomright=(self.width, self.height))],
        ]
        self.world_rect = [
            self.world[0][1],
            self.world[1][1],
            self.world[2][1],
            self.world[3][1],
        ]
        for i in range(4):
            self.world[i][0].fill(self.rock_color)


    def draw_world(self):
            for i in range(4):
                self.screen.blit(self.world[i][0], self.world[i][1])

    def display_settings(self, screen):

        score_Surface = self.font_settings.render("Score: " + str(self.score),False,"Red",)
        score_rect = score_Surface.get_rect(topleft = (30,5))

        m_amount_Surface = self.font_settings.render("Monster's alive: " + str(self.hellmonster.m_amount) + " / 10",False,"Red")
        m_amount_rect = m_amount_Surface.get_rect(topright = (self.width - 30,5))

        screen.blit(score_Surface,score_rect)
        screen.blit(m_amount_Surface,m_amount_rect)

    def restart(self):
        self.hellmonster.rect.clear()
        self.player.proj_rect.clear()
        self.player.speed_x = 0
        self.player.speed_y = 0
        self.player.start_y = self.height/2
        self.player.start_x = self.width/2
        self.player.game_over = False
        self.active = True
        self.player.move()
        self.hellmonster.hit = 0
        self.hellmonster.m_amount = 0

    def game_over(self, screen):
        game_over_surf = self.font.render("Game Over - Press Enter to Restart",True,"Red")
        game_over_rect = game_over_surf.get_rect(center = (self.width/2,self.height/2))

        screen.blit(game_over_surf,game_over_rect)
        self.active = False

    def running(self):
        up = False
        right = False
        down = False
        left = False

        pygame.init()

        while True:

            self.score = self.hellmonster.hit
            self.monster_amount = self.hellmonster.m_amount

            # Movement Player
            if self.active:
                if up and self.player.start_y > self.height/10:
                    self.player.move(0, -2)
                if down and self.player.start_y < self.height - self.height/10:
                    self.player.move(0, 2)
                if right and self.player.start_x < self.width - self.width/20:
                    self.player.move(2, 0)
                if left and self.player.start_x > self.width/20 :
                    self.player.move(-2, 0)

            for i in range(len(self.player.proj_rect)):
                self.hellmonster.get_shoot(self.player.proj_rect[i].rect)
                self.player.collision(self.player.proj_rect[i].rect,self.player.proj_rect[i].countdown)

            for events in pygame.event.get():
                if events.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()


                if events.type == pygame.KEYDOWN and self.active:
                    if events.key == pygame.K_w and self.player.start_y > self.height/10:
                        self.player.move(0,-1)
                        up = True
                    if events.key == pygame.K_s and self.player.start_y < self.height - self.height/10:
                        self.player.move(0,1)
                        down = True
                    if events.key == pygame.K_d and self.player.start_x < self.width - self.width/20:
                        self.player.move(1,0)
                        right = True
                    if events.key == pygame.K_a and self.player.start_x > self.width/20:
                        self.player.move(-1,0)
                        left = True

                    if events.key == pygame.K_SPACE:
                        self.player.shoot()

                if events.type == pygame.KEYUP:
                    if events.key == pygame.K_w:
                        up = False
                    if events.key == pygame.K_s:
                        down = False
                    if events.key == pygame.K_d:
                        right = False
                    if events.key == pygame.K_a:
                        left = False
                    if events.key == pygame.K_RETURN and not self.active:
                        self.active = True
                        self.restart()




            # Give Background a color
            self.screen.fill("#757878")

            # Draw Objects into the world
            # - Hellmonster
            if self.hellmonster.m_amount < 10 and self.active:
                self.hellmonster.spawn_monster(self.screen)
            # - Projectile
            self.player.draw_projectiles(self.screen,self.world_rect)
            # - Player
            self.player.draw(self.screen)
            # - Cave
            self.draw_world()
            # -
            self.display_settings(self.screen)

            if self.player.game_over == True:
                self.active = False

            if self.hellmonster.m_amount >= 10 or not self.active:
                self.game_over(self.screen)

            self.clock.tick(self.FPS)
            pygame.display.update()




if __name__ == "__main__":
    game = Reckless_App()
    game.running()
