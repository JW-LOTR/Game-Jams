import pygame
import random
from math import atan2
from math import degrees

class Projectile():

    def __init__(self, Player_pos_x, Player_pos_y):
        self.Surface = pygame.Surface((10,5))
        self.Surface.fill((128,0,0 ,1))
        self.countdown = 100
        self.konstante = atan2(pygame.mouse.get_pos()[0] - Player_pos_x,pygame.mouse.get_pos()[1] - Player_pos_y)
        if pygame.mouse.get_pos()[0] < Player_pos_x:
            self.konstante = atan2(pygame.mouse.get_pos()[0] - Player_pos_x, pygame.mouse.get_pos()[1] - Player_pos_y)
            self.speed_x =  ( Player_pos_x - pygame.mouse.get_pos()[0])/300 * self.konstante
            self.speed_y =  ( Player_pos_y - pygame.mouse.get_pos()[1])/300 * self.konstante
        else:
            self.speed_x = (pygame.mouse.get_pos()[0] - Player_pos_x) / 300 * self.konstante
            self.speed_y = ( pygame.mouse.get_pos()[1] - Player_pos_y) / 300 * self.konstante

        self.pos_x = Player_pos_x
        self.pos_y = Player_pos_y
        self.hit = 0
        self.colors = [(255,0,102,1),(247,0,255,1),(68,0,255,1),(0,222,255,1),(0,255,68,1),(213,255,0,1),(255,222,0,1)]
        self.rect = self.Surface.get_rect(center = (self.pos_x,self.pos_y))


    def move(self):

        self.pos_x += self.speed_x
        self.pos_y += self.speed_y
        self.rect.update(self.Surface.get_rect(center = (self.pos_x,self.pos_y)))

        self.countdown -= 1

    def colorize(self):
        self.Surface.fill(self.colors[self.hit])


    def collision(self,rect_list):
        index = 0
        for i in rect_list:
            if self.rect.colliderect(i):
                self.colorize()
                if self.hit <= 5:
                    self.hit += 1
                else:
                    self.hit = 0
                if index == 0 or index ==1:
                    self.speed_y *= -1

                if index == 2 or index == 3:
                    self.speed_x *= -1



            index += 1
class Player():

    def __init__(self,game_width,game_height):
        self.image = pygame.image.load("Images/Slime.png")
        self.image = pygame.transform.scale(self.image,(game_width/25,game_width/25))
        self.surface = self.image
        self.width_game = game_width
        self.height_game = game_height
        self.start_x = game_width/2
        self.start_y = game_height/2
        self.rect = self.surface.get_rect(center = (game_width/2,game_height/2))
        self.speed_x = 0
        self.speed_y = 0
        self.game_over = False
        self.proj_rect = []
        self.counter = 0

    def draw(self, screen):
        screen.blit(self.surface,self.rect)

    def move(self,x = 0, y = 0):
        if x != 0 and y != 0:
            self.start_y += 1.4142 * y/2
            self.start_x += 1.4142 * x/2
        else:
            self.start_y += y
            self.start_x += x
        self.speed_y = y
        self.speed_x = x
        self.rect.update(self.surface.get_rect(center = (self.start_x,self.start_y)))

        for i in range(len(self.proj_rect)):
            self.proj_rect[i].move()

        if self.counter % 50 == 0:
            self.surface = pygame.transform.scale(self.image, (self.width_game / 25, self.width_game / 25))

        if self.counter % 100 == 0:
            self.surface = pygame.transform.scale(self.image,(self.width_game/25,self.width_game/20))

        self.counter += 1
    def collision(self, rect, countdown):
        if countdown < 0 and self.rect.colliderect(rect):
            self.game_over = True



    def shoot(self):

        self.proj_rect.append(Projectile(self.start_x,self.start_y))

    def draw_projectiles(self, screen,rect_list):

        for i in range(len(self.proj_rect)):
            screen.blit(self.proj_rect[i].Surface,self.proj_rect[i].rect)

            self.proj_rect[i].collision(rect_list)



class Hellmonster():

    def __init__(self, game_width, game_height):
        self.game_width = game_width
        self.game_height = game_height
        self.rect = []
        self.hit = 0
        self.m_amount = 0

    def spawn_monster(self,screen):

        if random.randint(1,400) == 400:
            random_positions = [
                (random.randint(int(self.game_width/20), int(self.game_width- self.game_width/20)), int(self.game_height/20)),
                (random.randint(int(self.game_width / 20), int(self.game_width - self.game_width / 20)),int(self.game_height - self.game_height / 20)),
                (int(self.game_width / 40),random.randint(int(self.game_height / 10),int(self.game_height - self.game_height/10))),
                (int(self.game_width - self.game_width / 40),random.randint(int(self.game_height / 10),int(self.game_height - self.game_height/10))),
            ]

            a = pygame.Surface((25,25))
            a.fill("Red")

            self.rect.append([a,a.get_rect(center = random.choice(random_positions))])

            self.m_amount = len(self.rect)


        for i in range(len(self.rect)):
            screen.blit(self.rect[i][0],self.rect[i][1])

    def get_shoot(self, rect):
        for j in range(len(self.rect)):
            if rect.colliderect(self.rect[j][1]):
                self.rect.pop(j)
                self.m_amount -= 1
                self.hit += 1
                return
