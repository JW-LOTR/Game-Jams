import pygame, sys
import URUK, Worldgeneration, Obstacles, Shop
import random

pygame.init()

class Game:

    def __init__(self):
        self.width = 1000
        self.height = 650
        self.FPS = 100
        self.score = 0
        self.money = 0
        self.font_end = pygame.font.SysFont("Segoe UI",35)
        self.font_active = pygame.font.SysFont("Segoe UI",25,True)
        self.active = True
        self.screen = pygame.display.set_mode((self.width,self.height))
        self.char = URUK.Uruk(self.height/2,self.width/2)
        self.world_speed = self.char.speed_x
        self.world = Worldgeneration.Uruk_Worldgeneration(self.width,self.height)
        self.clock = pygame.time.Clock()
        self.obstacles_negative = []
        self.obstacles_jump = []
        self.obstacles_mobs = []
        self.tick = 0
        self.att_dictionary = {}
        with open("settings.txt") as file:
            for line in file:
                (key, value) = line.split()
                self.att_dictionary[key] = int(value)
        self.shops = [Shop.Shop(0,"speed"),Shop.Shop(1,"jump"),Shop.Shop(2,"jump_pad_y"),Shop.Shop(3,"reward")]

    def reset(self):
        self.obstacles_negative.clear()
        self.obstacles_mobs.clear()
        self.obstacles_jump.clear()
        self.char.reset()
        self.score = 0

    def update_settings(self, attribute,increase):
        if self.active:
            self.att_dictionary[attribute] += increase
            f = open("settings.txt", "w")
            n = []
            for i in self.att_dictionary:
                n.append([i]+ [str(self.att_dictionary[i])])

            for index in range(len(n)):
                f.writelines(n[index][0]+ " " + n[index][1] + "\n")
            f.close()

    def show_score(self):
        self.money = self.att_dictionary["money"]
        money_surface = self.font_active.render(str(self.money),True,"Green")
        font_surface = self.font_active.render(str(int(self.score)),True,"White")
        self.screen.blit(font_surface,font_surface.get_rect(midtop = (self.width/2, 50)))
        self.screen.blit(money_surface, money_surface.get_rect(midtop=(self.width / 8, 50)))

    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.money >= 300:
                    if self.shops[0].rect.collidepoint(pygame.mouse.get_pos()) and self.att_dictionary["speed"]<=12:
                        self.update_settings("speed",1)
                        self.update_settings("money",-self.shops[0].upgrade())
                        print(self.shops[0].upgrade_amount)

                    if self.shops[1].rect.collidepoint(pygame.mouse.get_pos()) and self.att_dictionary["jump"]>=-20:
                        self.update_settings("jump",-1)
                        self.update_settings("money",-self.shops[0].upgrade())

                    if self.shops[2].rect.collidepoint(pygame.mouse.get_pos()) and self.att_dictionary["jump_pad_y"]>=-25:
                        self.update_settings("jump_pad_y", -1)
                        self.update_settings("jump_pad_x", 1)
                        self.update_settings("money", -self.shops[0].upgrade())

                    if self.shops[3].rect.collidepoint(pygame.mouse.get_pos()) and self.att_dictionary["reward"]<=5:
                        self.update_settings("reward", 1)
                        self.update_settings("money", -self.shops[0].upgrade())

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and self.active:
                    self.char.diving = True

                if self.active == False:
                    if event.key == pygame.K_RETURN:
                        self.reset()
                        self.active = True

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_SPACE:
                    self.char.diving = False

        if self.char.diving == True:
            self.char.dive()

    def game_over(self):
        game_over_surface = self.font_end.render("Dead - Enter to Respawn",True,"Red")
        self.screen.blit(game_over_surface,game_over_surface.get_rect(center = (self.width/2,self.height/2)))


    def run(self):
        jump_spawn = False


        while True:

            self.att_dictionary = {}
            with open("settings.txt") as file:
                for line in file:
                    (key, value) = line.split()
                    self.att_dictionary[key] = int(value)

            # Alle Obstacles(Negative,Jump,Positiv) + Mobs
            obstacles = {
                1: Obstacles.Negativ_Obstacle(60, 20, pygame.image.load("Images/Stacheln_1.png"),
                                              pygame.image.load("Images/Stacheln_1_blood.png"), 25),
                2: Obstacles.Negativ_Obstacle(30, 90, pygame.image.load("Images/Schwert_2.png"),
                                              pygame.image.load("Images/Schwert_2_blood.png"), 25),
                3: Obstacles.Obstacle_Monster(50, 150, pygame.image.load("Images/Human_5.png"),
                                              pygame.image.load("Images/Human_5_dead.png"), 10),
                4: Obstacles.Jump_Obstacle(100, 30, pygame.image.load("Images/Jump_4.png"), self.att_dictionary["jump_pad_y"], self.att_dictionary["jump_pad_x"])
            }


            # Spawn Jump Obstacles
            if self.tick % 400 == 0:
                self.obstacles_jump.append(obstacles[4])
                jump_spawn = True
            # Spawn Obstacles
            if self.tick % 100 == 0 and not jump_spawn:

                # Create the Obstacle lists
                i = random.choice([0,1,2,3])
                # Negativ Obstacles
                if 2 >= i >0:
                    self.obstacles_negative.append(obstacles[i])
                # Monster Obstacles
                if i == 3:
                    self.obstacles_mobs.append(obstacles[i])

            jump_spawn = False

            # Background
            for index in range(2):
                self.world.background_rect.update(index*975-self.world.background_offset, 0, self.width, self.height)
                self.screen.blit(self.world.background,self.world.background_rect)

                self.screen.blit(self.world.world, self.world.world_rect[index])


            # Input
            self.events()

            # Draw Char
            self.screen.blit(self.char.texture,self.char.rect)
            # Draw Attribute bars
            self.char.draw_attributes(self.screen)
            # Draw Score
            self.show_score()
            # Draw Obstacles
            # - Negativ Obstacles
            for i in self.obstacles_negative:
                self.screen.blit(i.surface,i.rect)
            # - Monster Obstacles
            for i in self.obstacles_mobs:
                self.screen.blit(i.surface,i.rect)
            # - Jump Obstacles
            for i in self.obstacles_jump:
                self.screen.blit(i.surface,i.rect)

            # Draw Shops
            for i in self.shops:
                i.draw(self.screen)

            if self.char.stamina > 0:
                self.score += 0.05*self.att_dictionary["speed"]/2
                #Update Obstacles
                n = 0

                # - Negativ Obstacles
                for i in self.obstacles_negative:
                    i.move(self.world_speed)
                    if i.position < -80:
                        self.obstacles_negative.pop(n)
                        self.score += i.damage/2

                # - Monster Obstacles
                for i in self.obstacles_mobs:
                    i.move(self.world_speed)
                    if i.position < -80:
                        self.obstacles_mobs.pop(n)
                # - Jump Obstacles
                for i in self.obstacles_jump:
                    i.move(self.world_speed)
                    if i.position < -80:
                        self.obstacles_jump.pop(n)
                    n += 1

                #Update Background
                self.world.move_background(self.world_speed)
            else:
                self.update_settings("money",int(self.score/10))
                self.active = False
                self.game_over()
            #Update Player
            self.world_speed = self.char.speed_x
            self.char.move()
            self.char.collide_negative(self.obstacles_negative)
            self.char.collide_jump(self.obstacles_jump)
            self.char.collision_ground(self.world.world_rect)

            self.update_settings("money",int(self.char.collide_monster(self.obstacles_mobs))*self.att_dictionary["reward"])

            #Pygame Standard
            pygame.display.update()
            self.clock.tick(self.FPS)
            self.tick += 1

game = Game()

game.run()