import pygame

class Shop():
    def __init__(self,position_i,Attribute_name):
        self.width = 50
        self.height = 50
        self.position = position_i
        self.name = Attribute_name
        self.surface = pygame.image.load("Images/Shop_Upgrade.png")
        self.rect = self.surface.get_rect(bottomleft = (25,575-95*position_i))
        self.font = pygame.font.SysFont("Calibri",25, True)
        self.font_surface = self.font.render(str(Attribute_name),True,"#2596be")
        self.font_rect = self.font_surface.get_rect(bottomleft = (90,562-95*position_i))
        self.upgrade_amount = 0
        self.att_dictionary = {}
        with open("settings.txt") as file:
            for line in file:
                (key, value) = line.split()
                self.att_dictionary[key] = int(value)

        self.font_surface_stats = self.font.render(str(self.att_dictionary[Attribute_name]),True,"#2596be")
        self.font_rect_stats = self.font_surface_stats.get_rect(bottomleft = (40,525-95*position_i))

    def update_settings(self, attribute,increase):
        self.att_dictionary[attribute] += increase
        f = open("settings.txt", "w")
        n = []
        for i in self.att_dictionary:
            n.append([i]+ [str(self.att_dictionary[i])])

        for index in range(len(n)):
            f.writelines(n[index][0]+ " " + n[index][1] + "\n")
        f.close()

    def upgrade(self):
        self.upgrade_amount += 1

        return 300

    def draw(self, screen):

        self.att_dictionary = {}
        with open("settings.txt") as file:
            for line in file:
                (key, value) = line.split()
                self.att_dictionary[key] = int(value)

        self.font_surface_stats = self.font.render(str(self.att_dictionary[self.name]), True, "#2596be")
        self.font_rect_stats = self.font_surface_stats.get_rect(bottomleft=(40, 525 - 95 * self.position))

        screen.blit(self.surface,self.rect)
        screen.blit(self.font_surface,self.font_rect)
        screen.blit(self.font_surface_stats,self.font_rect_stats)