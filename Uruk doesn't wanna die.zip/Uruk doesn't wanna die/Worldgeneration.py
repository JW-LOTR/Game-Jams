import pygame

pygame.init()

class Uruk_Worldgeneration():

    def __init__(self, width,height):
        self.ground = 40
        self.world = pygame.image.load("Images/Ground.png")
        self.world_rect = [self.world.get_rect(bottomleft = (0,height)),self.world.get_rect(bottomleft = (1000,height))]
        self.background = pygame.image.load("Images/Background.jpg")
        self.background_rect = self.background.get_rect(bottomleft = (0,height))
        self.background_offset = 0

    def move_background(self, speed):
        self.background_offset += speed

        for i in range(2):
            self.world_rect[i].update(975*i-self.background_offset,610,1000,40)

        if self.background_offset >= 974:
            self.background_offset = 0
