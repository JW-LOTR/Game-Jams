import pygame

pygame.init()

class Uruk():
    def __init__(self, height, width):
        self.colliding = False
        self.coll_enemy = False
        self.att_dictionary = {}
        with open("settings.txt") as file:
            for line in file:
                (key, value) = line.split()
                self.att_dictionary[key] = int(value)
        self.energy = 100
        self.stamina = 100
        self.diving = False
        self.gravity = 0.6
        self.time = 0
        self.game_height = height
        self.game_width = width
        self.speed_x = self.att_dictionary["speed"]
        self.speed_x_set = 2
        self.speed_y = 2
        self.height = 150
        self.width = 60
        self.texture = pygame.image.load("Images/URUK_standing.png")
        self.rect = self.texture.get_rect(center = (self.game_width,self.game_height))

    def move(self):

        self.att_dictionary = {}
        with open("settings.txt") as file:
            for line in file:
                (key, value) = line.split()
                self.att_dictionary[key] = int(value)

        self.speed_x = self.att_dictionary["speed"]

        self.game_height += self.speed_y

        self.speed_y += self.time * self.gravity

        self.rect = self.texture.get_rect(center = (self.game_width,self.game_height))

        self.time += 1/100

        if self.speed_y > 0 and self.colliding == True:
            self.time = 0

        if self.speed_y > 0:
            if self.colliding:
                self.coll_enemy = False
            self.colliding = False

        if self.speed_x > self.att_dictionary["speed"]:
            self.speed_x -= 1/100

    def collision_ground(self,rect):

        for i in rect:
            if self.rect.colliderect(i) and self.colliding == False:
                self.speed_y = self.att_dictionary["jump"]
                self.time = 0
                self.colliding = True
                if self.stamina < 0:
                    self.speed_y = 0
                    self.game_height = 535
                    self.time = 0

    def collide_negative(self,obsticles):

        for i in obsticles:
            if self.rect.colliderect(i.rect) and self.coll_enemy == False:
                self.stamina -= i.damage
                self.coll_enemy = True
                i.update()

    def collide_jump(self,obsticles):

        for i in obsticles:
            if self.rect.colliderect(i.rect) and self.coll_enemy == False:
                self.speed_x += i.speed
                self.speed_y = i.jump
                self.time = 0
                self.colliding = True
                self.coll_enemy = True

    def collide_monster(self,obsticles):

        money = 0

        for i in obsticles:
            if self.rect.colliderect(i.rect) and self.coll_enemy == False and self.speed_y > 0:
                self.coll_enemy = True
                i.update()
                money += 10

        return money

    def dive(self):

        self.speed_y += 0.4

    def draw_attributes(self,screen):

        stamina_bar = pygame.image.load("Images/Attribute_Bar_V2.png")
        stamina_bar_rect = stamina_bar.get_rect(topleft = (self.game_width*2-150, 50))
        if self.stamina > 0:
            pygame.draw.ellipse(screen,"Red",pygame.Rect(self.game_width*2-149, 50, 26, 48))
            pygame.draw.rect(screen, "Red", pygame.Rect(self.game_width*2-137, 50, self.stamina * 0.87, 50))

        screen.blit(stamina_bar, stamina_bar_rect)

    def reset(self):
        self.stamina = 100
        self.speed_x = 2
        self.rect = self.texture.get_rect(center = (self.game_width,self.game_height))