import pygame, random

class Obstacle():
    def __init__(self,width,height,image,image_blood):
        self.surface = image
        self.image_blood = image_blood
        self.game_height = 650
        self.game_width = 1000
        self.hit = False
        self.width = width
        self.height = height
        self.position = self.game_width+random.randint(10,40)
        self.rect = self.surface.get_rect(bottomleft = (self.position,self.game_height-40))

    def move(self,speed):
        self.position -= speed
        self.rect.update(self.position,self.game_height-40-self.height,self.width,self.height)

    def update(self):
        self.surface = self.image_blood

class Negativ_Obstacle(Obstacle):
    def __init__(self,width,height,image,image_blood,damage):
        super(Negativ_Obstacle, self).__init__(width,height,image,image_blood)
        self.damage = damage

    def action(self, stamina):
        stamina -= self.damage

        return stamina

class Jump_Obstacle(Obstacle):
    def __init__(self, width,height,image,jump, speed):
        super(Jump_Obstacle, self).__init__(width,height,image,image)
        self.jump = jump
        self.speed = speed

class Obstacle_Monster(Obstacle):
    def __init__(self, width,height,image,image_blood,reward):
        super(Obstacle_Monster, self).__init__(width,height,image,image_blood)
        self.reward = reward
