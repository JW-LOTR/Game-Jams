import pygame

class Teleportfeld():

    def __init__(self):
        self.image =pygame.image.load("Images/Teleport_Field.png")
        self.image = pygame.transform.scale(self.image,(50,50))
        self.pos_x_1 = 0
        self.pos_y_1 = 0
        self.pos_x_2 = 0
        self.pos_y_2 = 0