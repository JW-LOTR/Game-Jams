import sys
import Button,Player
import pygame

pygame.init()


class TimeRunner():
    width = 1200
    height = 650
    framerate = 60
    main_font = pygame.font.SysFont("calibri",40, True)
    side_font = pygame.font.SysFont("calibri",20, False)
    teleport_locations = []
    # Alle verfügbaren Levels
    levels = [
        [
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4]
        ],
        [
            [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2],
            [0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 1, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 1, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4]
        ],
        [
            [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 3, 0, 1, 1, 1, 1, 1, 0],
            [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0],
            [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1],
            [1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 3, 0, 0, 0, 0, 3],
            [0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 1, 0, 0, 1, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 1, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 1, 3, 0, 3, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 4]
        ],
        [
            [1, 1, 1, 1, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 1, 1],
            [1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
            [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 3, 1, 0, 0, 0, 1],
            [1, 1, 3, 0, 3, 0, 3, 0, 1, 3, 0, 1, 1, 3, 0, 1, 1, 0, 0, 3],
            [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 3, 0, 3, 0, 0, 0],
            [1, 0, 1, 1, 1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 1, 3, 0, 1, 1, 3, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 3, 0, 1, 0, 0, 0, 0, 0, 4]
        ],
        [
            [1, 3, 0, 3, 0, 3, 1, 1, 3, 1, 3, 0, 1, 0, 0, 0, 0, 0, 0, 0],
            [3, 0, 0, 1, 0, 0, 0, 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0],
            [1, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [1, 1, 3, 0, 3, 0, 3, 3, 3, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 1, 0, 3, 0, 3, 0, 3, 1, 3, 0, 1, 3, 1, 3, 0, 1, 1],
            [1, 0, 0, 3, 0, 0, 0, 3, 0, 0, 0, 0, 1, 3, 0, 3, 0, 0, 0, 0],
            [0, 3, 0, 0, 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [1, 0, 3, 1, 0, 0, 0, 3, 0, 1, 0, 0, 0, 3, 0, 3, 0, 0, 0, 0],
            [1, 3, 0, 3, 3, 3, 0, 3, 0, 1, 0, 0, 0, 0, 2, 1, 3, 0, 1, 1],
            [0, 1, 1, 0, 1, 2, 3, 1, 3, 1, 3, 0, 1, 3, 0, 1, 0, 0, 0, 4]
        ],
        [
            [1, 3, 0, 3, 0, 3, 1, 1, 3, 1, 3, 0, 1, 0, 0, 0, 0, 0, 0, 0],
            [3, 0, 0, 1, 0, 0, 0, 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0],
            [1, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 0, 3, 0, 3, 1, 2, 0, 0, 0],
            [1, 1, 3, 0, 3, 0, 3, 3, 3, 0, 1, 0, 3, 0, 1, 0, 0, 0, 0, 0],
            [0, 0, 0, 1, 0, 3, 0, 3, 0, 3, 1, 3, 0, 1, 3, 1, 3, 0, 1, 1],
            [1, 0, 0, 3, 0, 0, 0, 3, 0, 0, 0, 0, 1, 3, 1, 3, 0, 0, 0, 0],
            [0, 3, 0, 0, 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [1, 0, 3, 1, 0, 0, 0, 3, 0, 1, 0, 0, 0, 3, 0, 3, 0, 0, 0, 0],
            [1, 3, 0, 3, 3, 3, 0, 3, 0, 1, 3, 0, 1, 1, 2, 1, 3, 0, 1, 1],
            [0, 1, 1, 0, 1, 1, 3, 1, 3, 1, 3, 0, 1, 3, 0, 1, 0, 0, 0, 4]
        ],
        [
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4]
        ],
        [
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4]
        ],
        [
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4]
        ],
        [
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4]
        ],
        [
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4]
        ],
    ]

    def __init__(self):
        self.screen = pygame.display.set_mode((self.width,self.height))
        self.clock = pygame.time.Clock()
        self.player = Player.Player(pygame.image.load("Images/Player.png"))
        self.level = 0
        self.score = 0
        self.level_coins = 3000
        self.last_direction = ""

    def main_screen(self):
        buttonsurface = pygame.image.load("Images/button.png")
        buttonsurface = pygame.transform.scale(buttonsurface, (350, 125))
        background = pygame.image.load("Images/Mainmenu_background.jpg")
        background = pygame.transform.scale(background,(self.width,self.height))
        font = pygame.font.SysFont("calibri",80,True)
        main_title = font.render("Time Runner",True,"Orange")

        while True:

            self.screen.blit(background,background.get_rect(center = (self.width/2,self.height/2)))
            play_button = Button.Button(buttonsurface, self.width / 2, self.height / 2, "Play")
            play_button.update(self.screen)
            quit_button = Button.Button(buttonsurface, self.width / 2, self.height / 1.2, "Quit")
            quit_button.update(self.screen)
            self.screen.blit(main_title,main_title.get_rect(center = (self.width/2,self.height/5)))

            for events in pygame.event.get():
                if events.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if events.type == pygame.MOUSEBUTTONDOWN:
                    if play_button.checkForInput(pygame.mouse.get_pos()):
                        self.run()
                    if quit_button.checkForInput(pygame.mouse.get_pos()):
                        pygame.quit()
                        sys.exit()



            pygame.display.update()
            self.clock.tick(self.framerate)

    def teleport_set(self):

        # Teleportmöglichkeiten bei dem Level
        self.teleport_locations = []
        # Level wird für die Teleports geladen
        m = 0
        for i in self.levels[self.level]:
            n = 0
            for j in i:
                if j == 2:
                    self.teleport_locations.append((n * 50, m * 50))
                n += 1
            m += 1


    def run(self):


        #PlayScreen + Hintergrund
            # Screen auf dem sich der Spieler bewegen kann
        Playground = pygame.Surface((1000, 500))
        Playground.fill("red")
        Playground_rect = Playground.get_rect(center=(self.width / 2, 375))
            # Hintergrund für den "Playground" laden
        Play_background = pygame.image.load("Images/Sky_Background.jpg")
        Play_background = pygame.transform.scale(Play_background, ((1000, 500)))
            # Hintergrund für den Play-Screen laden
        Playscreen_background = pygame.image.load("Images/brick-wall-background.jpg")
        Playscreen_background = pygame.transform.scale(Playscreen_background,(self.width,self.height))

        # Alle Font Surfaces werden initialisiert
        Title_Surface = self.main_font.render("Time Runner",True,"Orange")
        Title_Rect = Title_Surface.get_rect(center = (self.width/2,60))

        # Die einzelnen Felder, welche der Spieler betreten kann
            # -Normales Field
        Spielfeld = pygame.image.load("Images/Ground_Field.png")
        Spielfeld = pygame.transform.scale(Spielfeld, (50, 50))
            # -Teleport Field
        Teleport = pygame.image.load("Images/Teleport_Field.png")
        Teleport = pygame.transform.scale(Teleport, (50, 50))
            # -Jump Field
        Jumpfeld = pygame.image.load("Images/Jump_Field.png")
        Jumpfeld = pygame.transform.scale(Jumpfeld, (50, 50))
            # -Ziel
        Zielfeld = pygame.image.load("Images/Ziel.png")
        Zielfeld = pygame.transform.scale(Zielfeld,(50,50))

        self.teleport_set()

        while True:

            if self.level_coins >= 2:
                self.level_coins -= 1

            # Input für den Spieler
            for events in pygame.event.get():
                if events.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if events.type == pygame.KEYDOWN:
                    if events.key == pygame.K_DOWN:
                        self.player.move("down")
                        self.last_direction = "down"
                    if events.key == pygame.K_LEFT:
                        self.player.move("left")
                        self.last_direction = "left"
                    if events.key == pygame.K_RIGHT:
                        self.player.move("right")
                        self.last_direction = "right"

            # Überprüft, ob Spieler versagt hat oder das Level geschafft hat
            self.player.dead(self.levels[self.level],self.teleport_locations,self.last_direction)
            if self.player.finished():
                self.score += self.level_coins
                self.level_coins = 3000
                self.level += 1
                self.teleport_locations.clear()
                self.teleport_set()
                if self.level == 6:
                    self.finish_screen()
            # Es werden alle nicht spielrelevanten Sachen auf den Screen getan
            self.screen.blit(Playscreen_background,Playscreen_background.get_rect(center = (self.width/2,self.height/2)))
            pygame.draw.rect(self.screen,"#ffffff",pygame.Rect(90,115,1020,520))
            self.screen.blit(Playground,Playground_rect)
            Playground.blit(Play_background,Play_background.get_rect(topleft = (0,0)))

            # Es werden alle Fonts gerendert
            Level_Surface = self.main_font.render("Level: "+str(self.level), True, "Orange")
            Level_Rect = Level_Surface.get_rect(midleft=(100, 60))
            Score_Surface = self.main_font.render("Score: "+str(self.score), True, "Orange")
            Score_Rect = Score_Surface.get_rect(midright=(1100, 60))
            Score_mini_Surface = self.side_font.render(str(self.level_coins), True, "Orange")
            Score_mini_Rect = Score_mini_Surface.get_rect(midright=(1100, 85))
            self.screen.blit(Title_Surface,Title_Rect)
            self.screen.blit(Level_Surface,Level_Rect)
            self.screen.blit(Score_Surface,Score_Rect)
            self.screen.blit(Score_mini_Surface,Score_mini_Rect)

            # Level wird geladen / Auf den Screen geladen
            m = 0
            for i in self.levels[self.level]:
                n = 0
                for j in i:
                    if j == 1:
                        Playground.blit(Spielfeld,Spielfeld.get_rect(topleft = (n*50,m*50)))
                    elif j == 2:
                        Playground.blit(Teleport,Teleport.get_rect(topleft = (n*50,m*50)))
                    elif j == 3:
                        Playground.blit(Jumpfeld,Jumpfeld.get_rect(topleft = (n*50,m*50)))
                    elif j == 4:
                        Playground.blit(Zielfeld,Zielfeld.get_rect(topleft = (n*50,m*50)))
                    n+=1
                m+=1

            # Spieler wird geladen
            self.player.update(Playground)

            # Standard Python
            self.clock.tick(self.framerate)
            pygame.display.update()

    def reset(self):
        self.score = 0
        self.level = 0

    def finish_screen(self):
        buttonsurface = pygame.image.load("Images/button.png")
        buttonsurface = pygame.transform.scale(buttonsurface, (350, 125))
        background = pygame.image.load("Images/Mainmenu_background.jpg")
        background = pygame.transform.scale(background,(self.width,self.height))
        font = pygame.font.SysFont("calibri",80,True)
        font_2 = pygame.font.SysFont("calibri",40,True)
        main_title = font.render("Thanks for playing",True,"Orange")
        score = font_2.render("Score: " + str(self.score),True,"Orange")

        while True:

            self.screen.blit(background,background.get_rect(center = (self.width/2,self.height/2)))
            play_button = Button.Button(buttonsurface, self.width / 2, self.height / 2, "Play again")
            play_button.update(self.screen)
            quit_button = Button.Button(buttonsurface, self.width / 2, self.height / 1.2, "Quit")
            quit_button.update(self.screen)
            self.screen.blit(main_title,main_title.get_rect(center = (self.width/2,self.height/5)))
            self.screen.blit(score,score.get_rect(center = (self.width/2,self.height/3)))

            for events in pygame.event.get():
                if events.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if events.type == pygame.MOUSEBUTTONDOWN:
                    if play_button.checkForInput(pygame.mouse.get_pos()):
                        self.reset()
                        self.run()
                    if quit_button.checkForInput(pygame.mouse.get_pos()):
                        pygame.quit()
                        sys.exit()



            pygame.display.update()
            self.clock.tick(self.framerate)

if __name__ == '__main__':
    app = TimeRunner()
    app.main_screen()
