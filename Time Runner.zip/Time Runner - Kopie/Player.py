import pygame

class Player():

    def __init__(self,image):
        self.pos_x = 0
        self.pos_y = 0
        self.image = image
        self.image = pygame.transform.scale(self.image,(50,50))
        self.teleport = False
        self.rect = self.image.get_rect(topleft = (self.pos_x,self.pos_y))

    def update(self,screen):
        self.rect.update(self.image.get_rect(topleft = (self.pos_x,self.pos_y)))
        screen.blit(self.image,self.rect)

    def move(self,direction):
        if direction == "right" and self.pos_x <950:
            self.pos_x += 50
        if direction == "left" and self.pos_x > 0:
            self.pos_x -= 50
        if direction == "down" and self.pos_y < 450:
            self.pos_y += 50

    def finished(self):

        if self.pos_x == 950 and self.pos_y == 450:
            self.pos_x = 0
            self.pos_y = 0
            return 1
        else:
            return 0

    def dead(self, level,teleport_location,direction):


        if level[int(self.pos_y/50)][int(self.pos_x/50)] == 0:
            self.pos_x = 0
            self.pos_y = 0


        if level[int(self.pos_y/50)][int(self.pos_x/50)] == 2 and not self.teleport:

            if (self.pos_x,self.pos_y) == teleport_location[0]:

                self.pos_x = teleport_location[1][0]
                self.pos_y = teleport_location[1][1]

            elif (self.pos_x,self.pos_y) == teleport_location[1]:
                self.pos_x = teleport_location[0][0]
                self.pos_y = teleport_location[0][1]

            self.teleport = True

        if level[int(self.pos_y/50)][int(self.pos_x/50)] == 3:

            if direction == "down" and self.pos_y <=350:
                self.pos_y += 100

            if direction == "left" and self.pos_x >= 100:
                self.pos_x -= 100

            if direction == "right" and self.pos_x <=850:
                self.pos_x += 100

        if level[int(self.pos_y/50)][int(self.pos_x/50)] != 2:
            self.teleport = False